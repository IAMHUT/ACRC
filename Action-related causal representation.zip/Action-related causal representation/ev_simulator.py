"""
EV_Simulator.py
高保真电动汽车仿真环境
"""

import numpy as np
from collections import deque
from typing import Tuple, Dict, List
import warnings

warnings.filterwarnings('ignore')


class HighFidelityEVSimulator:
    """
    具有验证动力学的高保真电动汽车仿真器
    匹配第6.1节中描述的实验平台
    """

    def __init__(self,
                 config: Dict = None):

        # 匹配论文规格的默认配置
        self.config = config or {
            # 车辆参数
            'mass': 1500.0,  # kg
            'wheel_radius': 0.3,  # m
            'drag_coefficient': 0.3,
            'frontal_area': 2.2,  # m²
            'rolling_resistance': 0.01,
            'motor_efficiency_nominal': 0.85,
            'battery_capacity': 60.0,  # kWh
            'max_brake_torque': 100.0,  # N·m

            # 环境参数
            'air_density': 1.225,  # kg/m³
            'gravity': 9.81,  # m/s²

            # 传感器参数
            'velocity_noise_std': 0.02,  # ±2%
            'soc_noise_std': 0.05,  # ±5%
            'distance_noise_std': 0.05,  # ±5%
            'sensor_latency': 0.02,  # 20ms

            # 驾驶员行为配置文件
            'driver_profile': 'normal',  # 'normal', 'aggressive', 'eco'
            'braking_anticipation': 0.5,  # 经济型驾驶员预判

            # 电池老化模拟
            'battery_degradation': 1.0,  # 1.0 = 标称容量
            'battery_internal_resistance': 0.1,  # 欧姆

            # 仿真参数
            'time_step': 0.1,  # s
            'max_steps': 1000
        }

        # 初始化基本属性
        self.motor_temperature = 30.0  # 先初始化一个默认值
        self.battery_temperature = 25.0

        # 初始化驾驶循环
        self._initialize_driving_cycles()

        # 电机效率图（扭矩，速度）-> 效率
        self._initialize_motor_efficiency_map()

        # 电池模型参数
        self._initialize_battery_model()

        # 状态空间定义（匹配论文）- 修正为22以匹配实际观测维度
        self.state_dim = 22  # 修改为22，因为_get_observation返回22个特征
        self.action_dim = 1
        self.action_space_low = -self.config['max_brake_torque']
        self.action_space_high = 0.0

        # 初始化状态变量
        self.reset()

    def reset(self, driving_cycle: str = 'urban'):
        """将仿真器重置为初始状态"""

        # 步骤计数器 - 必须在这里初始化，因为后面的_get_target_velocity需要它
        self.step_count = 0

        # 核心状态变量
        self.time = 0.0
        self.position = 0.0
        self.velocity = 10.0  # m/s
        self.acceleration = 0.0
        self.jerk = 0.0

        # 电池状态
        self.soc = 0.7  # 充电状态
        self.battery_temperature = 25.0  # °C
        self.battery_current = 0.0

        # 电机状态
        self.motor_torque = 0.0
        self.motor_speed = self.velocity / self.config['wheel_radius']
        self.motor_temperature = 30.0

        # 制动系统
        self.brake_pedal_position = 0.0
        self.brake_torque_demand = 0.0
        self.brake_torque_actual = 0.0

        # 环境状态
        self.road_grade = 0.0  # 弧度
        self.ambient_temperature = 20.0
        self.wind_speed = 0.0
        self.wind_direction = 0.0

        # 交通状态
        self.lead_vehicle_distance = 50.0  # m
        self.lead_vehicle_velocity = 12.0  # m/s
        self.lead_vehicle_acceleration = 0.0

        # 驾驶员意图
        self.target_velocity = self._get_target_velocity(driving_cycle)
        self.braking_intent = 0.0

        # 用于加加速度计算的历史记录
        self.acceleration_history = deque(maxlen=3)
        self.acceleration_history.append(0.0)

        # 能量追踪
        self.energy_recovered_total = 0.0
        self.energy_consumed_total = 0.0
        self.kinetic_energy_lost_total = 0.0

        # 安全指标
        self.safety_violations = 0
        self.near_collisions = 0

        # 生成初始传感器观测
        return self._get_observation()

    def _initialize_motor_efficiency_map(self):
        """根据测功机数据初始化电机效率图"""

        # 创建效率图：η = f(扭矩, 速度)
        torque_range = np.linspace(-100, 100, 21)
        speed_range = np.linspace(0, 200, 21)

        self.motor_efficiency_map = np.zeros((len(torque_range), len(speed_range)))

        for i, torque in enumerate(torque_range):
            for j, speed in enumerate(speed_range):
                if speed == 0:
                    efficiency = 0.0
                else:
                    # 基础效率曲线
                    base_efficiency = 0.85

                    # 扭矩依赖
                    torque_factor = 1.0 - 0.3 * abs(torque) / 100

                    # 速度依赖
                    speed_factor = 1.0 - 0.2 * abs(speed) / 100

                    # 温度依赖 - 使用当前电机温度
                    temp_factor = 1.0 - 0.1 * (self.motor_temperature - 30) / 50

                    efficiency = (base_efficiency *
                                  torque_factor *
                                  speed_factor *
                                  temp_factor)

                    # 裁剪到有效范围
                    efficiency = np.clip(efficiency, 0.0, 0.95)

                self.motor_efficiency_map[i, j] = efficiency

        self.torque_range = torque_range
        self.speed_range = speed_range

    def _initialize_battery_model(self):
        """初始化等效电路电池模型"""

        # 电池参数（典型锂离子电池）
        self.battery_params = {
            'nominal_capacity': self.config['battery_capacity'] * 1e3 * 3600,  # 焦耳
            'internal_resistance': self.config['battery_internal_resistance'],
            'open_circuit_voltage': 400.0,  # V
            'voltage_range': [300.0, 420.0],
            'temperature_coefficient': 0.003,  # 每°C
            'capacity_degradation_factor': self.config['battery_degradation']
        }

        # 充电状态到开路电压曲线
        self.soc_ocv_curve = lambda soc: (
                300.0 + 120.0 * soc - 20.0 * (soc - 0.5) ** 2
        )

        # 内阻作为SOC和温度的函数
        self.internal_resistance_func = lambda soc, temp: (
                self.battery_params['internal_resistance'] *
                (1.0 + 0.5 * (0.5 - soc) ** 2) *
                (1.0 + 0.002 * (temp - 25.0))
        )

    def _initialize_driving_cycles(self):
        """初始化标准驾驶循环"""

        # WLTC 3级（城市）
        self.driving_cycles = {
            'urban': {
                'duration': 1800,  # s
                'velocity_profile': self._generate_velocity_profile(
                    mean_velocity=15.0,
                    std_velocity=5.0,
                    stop_frequency=0.02,
                    acceleration_mean=0.5,
                    acceleration_std=0.3
                )
            },
            'highway': {
                'duration': 1200,
                'velocity_profile': self._generate_velocity_profile(
                    mean_velocity=25.0,
                    std_velocity=3.0,
                    stop_frequency=0.001,
                    acceleration_mean=0.3,
                    acceleration_std=0.2
                )
            },
            'mixed': {
                'duration': 2400,
                'velocity_profile': self._generate_velocity_profile(
                    mean_velocity=18.0,
                    std_velocity=8.0,
                    stop_frequency=0.01,
                    acceleration_mean=0.4,
                    acceleration_std=0.4
                )
            }
        }

    def _generate_velocity_profile(self,
                                   mean_velocity: float,
                                   std_velocity: float,
                                   stop_frequency: float,
                                   acceleration_mean: float,
                                   acceleration_std: float) -> np.ndarray:
        """生成真实的速度配置文件"""

        duration = 2400  # 40分钟
        time_steps = np.arange(0, duration, self.config['time_step'])

        # 基础配置文件，带有趋势
        base_profile = (mean_velocity +
                        std_velocity * np.sin(2 * np.pi * time_steps / 600) +
                        0.5 * std_velocity * np.sin(2 * np.pi * time_steps / 120))

        # 添加随机变化
        random_walk = np.cumsum(np.random.randn(len(time_steps)) * 0.1)
        random_walk = random_walk - random_walk.mean()

        profile = base_profile + 0.3 * std_velocity * random_walk

        # 添加停车
        stop_mask = np.random.rand(len(time_steps)) < stop_frequency
        profile[stop_mask] = 0.0

        # 平滑配置文件
        from scipy.ndimage import gaussian_filter1d
        profile = gaussian_filter1d(profile, sigma=10)

        # 确保非负
        profile = np.maximum(profile, 0.0)

        return profile

    def _get_target_velocity(self, driving_cycle: str) -> float:
        """基于驾驶循环获取目标速度"""

        if driving_cycle in self.driving_cycles:
            cycle_idx = min(self.step_count,
                            len(self.driving_cycles[driving_cycle]['velocity_profile']) - 1)
            return self.driving_cycles[driving_cycle]['velocity_profile'][cycle_idx]
        else:
            # 默认：带噪声的恒定速度
            return 15.0 + 2.0 * np.sin(self.time / 10)

    def _get_observation(self) -> np.ndarray:
        """获取完整的观测向量（第4.2节）"""

        # 添加传感器噪声
        velocity_noise = np.random.normal(0, self.config['velocity_noise_std'] * self.velocity)
        soc_noise = np.random.normal(0, self.config['soc_noise_std'])
        distance_noise = np.random.normal(0, self.config['distance_noise_std'] * self.lead_vehicle_distance)

        # 状态向量（匹配论文规范）
        observation = np.array([
            # 车辆动力学（因果变量）
            self.velocity + velocity_noise,  # v
            self.acceleration,  # a
            self.jerk,  # jerk

            # 电池状态（因果变量）
            np.clip(self.soc + soc_noise, 0.0, 1.0),  # SOC
            self.battery_temperature,  # T_batt
            self.battery_current,  # I_batt

            # 电机状态（因果变量）
            self.motor_torque,  # T_motor
            self.motor_speed,  # ω_motor
            self.motor_temperature,  # T_motor

            # 制动系统（因果变量）
            self.brake_pedal_position,  # β
            self.brake_torque_demand,  # T_brake_demand
            self.brake_torque_actual,  # T_brake_actual

            # 环境状态（部分因果）
            self.road_grade,  # θ_grade
            self.ambient_temperature,  # T_amb
            self.wind_speed,  # v_wind

            # 交通状态（安全相关因果）
            max(0.0, self.lead_vehicle_distance + distance_noise),  # d_lead
            self.lead_vehicle_velocity,  # v_lead
            self.lead_vehicle_acceleration,  # a_lead

            # 驾驶员意图（因果）
            self.target_velocity,  # v_target
            self.braking_intent,  # braking_intent

            # 非因果特征（用于测试鲁棒性）
            np.random.uniform(0, 1),  # random_feature_1
            np.random.uniform(0, 1),  # random_feature_2
        ], dtype=np.float32)

        return observation

    def step(self, action: np.ndarray) -> Tuple[np.ndarray, float, bool, Dict]:
        """
        执行一个仿真步

        参数：
            action: 制动扭矩命令 [N·m]，负值表示制动

        返回：
            observation, reward, done, info
        """

        self.step_count += 1  # 现在可以安全递增step_count
        dt = self.config['time_step']

        # ========== 1. 处理动作 ==========
        brake_torque_cmd = float(action[0])

        # 裁剪到有效范围
        brake_torque_cmd = np.clip(
            brake_torque_cmd,
            -self.config['max_brake_torque'],
            0.0
        )

        # 建模执行器动力学（一阶滞后）
        actuator_time_constant = 0.05  # 50ms
        self.brake_torque_actual = (
                self.brake_torque_actual +
                (brake_torque_cmd - self.brake_torque_actual) *
                dt / actuator_time_constant
        )

        # ========== 2. 计算力 ==========

        # 制动力
        brake_force = abs(self.brake_torque_actual) / self.config['wheel_radius']

        # 空气阻力
        drag_force = 0.5 * self.config['air_density'] * \
                     self.config['drag_coefficient'] * \
                     self.config['frontal_area'] * \
                     (self.velocity + self.wind_speed) ** 2

        # 滚动阻力
        rolling_force = self.config['rolling_resistance'] * \
                        self.config['mass'] * \
                        self.config['gravity'] * \
                        np.cos(self.road_grade)

        # 坡度力
        grade_force = self.config['mass'] * \
                      self.config['gravity'] * \
                      np.sin(self.road_grade)

        # 总阻力
        total_resistive_force = (
                brake_force +
                drag_force +
                rolling_force +
                grade_force
        )

        # ========== 3. 更新车辆动力学 ==========

        # 加速度（制动时为负值）
        new_acceleration = -total_resistive_force / self.config['mass']

        # 加加速度（加速度变化率）
        self.jerk = (new_acceleration - self.acceleration) / dt

        # 更新加速度
        self.acceleration = new_acceleration
        self.acceleration_history.append(self.acceleration)

        # 更新速度
        self.velocity = max(0.0, self.velocity + self.acceleration * dt)

        # 更新位置
        self.position += self.velocity * dt

        # 更新电机转速
        self.motor_speed = self.velocity / self.config['wheel_radius']

        # ========== 4. 再生制动 ==========

        if self.brake_torque_actual < 0 and self.velocity > 0:
            # 计算动能损失
            kinetic_energy_initial = 0.5 * self.config['mass'] * \
                                     (self.velocity - self.acceleration * dt) ** 2
            kinetic_energy_final = 0.5 * self.config['mass'] * self.velocity ** 2
            kinetic_energy_loss = kinetic_energy_initial - kinetic_energy_final

            # 获取电机效率
            torque_idx = np.argmin(np.abs(self.torque_range - self.brake_torque_actual))
            speed_idx = np.argmin(np.abs(self.speed_range - self.motor_speed))
            motor_efficiency = self.motor_efficiency_map[torque_idx, speed_idx]

            # 计算再生能量
            regen_power = abs(self.brake_torque_actual) * self.motor_speed * motor_efficiency
            regen_energy = regen_power * dt

            # 受动能损失限制
            regen_energy = min(regen_energy, kinetic_energy_loss)

            # 更新能量追踪
            self.energy_recovered_total += regen_energy
            self.kinetic_energy_lost_total += kinetic_energy_loss

            # 电池充电
            self._update_battery(regen_energy, charging=True)

        else:
            regen_energy = 0.0
            kinetic_energy_loss = 0.0

        # ========== 5. 更新电池状态 ==========

        # 自放电和辅助负载
        auxiliary_power = 500.0  # W（灯光、电子设备等）
        auxiliary_energy = auxiliary_power * dt
        self._update_battery(auxiliary_energy, charging=False)

        # ========== 6. 更新热动力学 ==========

        self._update_thermal_dynamics(dt)

        # ========== 7. 更新交通状态 ==========

        self._update_traffic(dt)

        # ========== 8. 更新驾驶员意图 ==========

        self._update_driver_intent(dt)

        # ========== 9. 计算奖励 ==========

        reward = self._calculate_reward(
            brake_torque_cmd,
            regen_energy,
            kinetic_energy_loss
        )

        # ========== 10. 检查终止条件 ==========

        done = self._check_termination()

        # ========== 11. 更新时间 ==========

        self.time += dt

        # ========== 12. 准备信息字典 ==========

        info = {
            'velocity': self.velocity,
            'acceleration': self.acceleration,
            'jerk': self.jerk,
            'soc': self.soc,
            'energy_recovered': regen_energy,
            'energy_recovery_efficiency': (
                regen_energy / kinetic_energy_loss if kinetic_energy_loss > 0 else 0.0
            ),
            'brake_torque': self.brake_torque_actual,
            'motor_efficiency': motor_efficiency if 'motor_efficiency' in locals() else 0.0,
            'safety_violations': self.safety_violations,
            'step': self.step_count,
            'time': self.time
        }

        # ========== 13. 获取下一个观测 ==========

        observation = self._get_observation()

        return observation, reward, done, info

    def _update_battery(self, energy: float, charging: bool):
        """更新电池充电状态"""

        # 考虑电池退化调整
        effective_capacity = (
                self.battery_params['nominal_capacity'] *
                self.battery_params['capacity_degradation_factor']
        )

        if charging:
            # 充电效率
            charging_efficiency = 0.95  # 95%效率

            # 充电期间的电流
            voltage = self.soc_ocv_curve(self.soc)
            resistance = self.internal_resistance_func(self.soc, self.battery_temperature)

            # 解电流方程：P = V*I - I^2*R
            # I^2*R - V*I + P = 0
            power = energy / self.config['time_step']
            a = resistance
            b = -voltage
            c = power

            discriminant = b ** 2 - 4 * a * c
            if discriminant >= 0:
                current = (-b - np.sqrt(discriminant)) / (2 * a)
                self.battery_current = current

                # 更新SOC
                charge_added = current * self.config['time_step'] * charging_efficiency
                self.soc += charge_added / effective_capacity
            else:
                # 备用方案：简单SOC更新
                self.soc += energy * charging_efficiency / effective_capacity
        else:
            # 放电
            discharge_efficiency = 0.98  # 98%效率

            # 更新SOC
            self.soc -= energy * discharge_efficiency / effective_capacity

        # 裁剪SOC到有效范围
        self.soc = np.clip(self.soc, 0.0, 1.0)

        # 更新电池温度
        power_loss = self.battery_current ** 2 * \
                     self.internal_resistance_func(self.soc, self.battery_temperature)
        temperature_rise = power_loss * self.config['time_step'] / (1000.0 * 0.5)  # 0.5 kg, 1 kJ/kg·K
        self.battery_temperature += temperature_rise

    def _update_thermal_dynamics(self, dt: float):
        """更新电机和电池温度"""

        # 电机温度
        motor_power_loss = abs(self.brake_torque_actual) * \
                           self.motor_speed * \
                           (1.0 - (self.motor_efficiency_map[
                                       np.argmin(np.abs(self.torque_range - self.brake_torque_actual)),
                                       np.argmin(np.abs(self.speed_range - self.motor_speed))
                                   ] if hasattr(self, 'motor_efficiency_map') else 0.85))

        motor_temp_rise = motor_power_loss * dt / (1000.0 * 0.8)  # 0.8 kg, 1 kJ/kg·K
        motor_cooling = 0.1 * (self.motor_temperature - self.ambient_temperature) * dt

        self.motor_temperature += motor_temp_rise - motor_cooling
        self.motor_temperature = np.clip(self.motor_temperature, 20.0, 120.0)

        # 电池冷却
        battery_cooling = 0.05 * (self.battery_temperature - self.ambient_temperature) * dt
        self.battery_temperature -= battery_cooling
        self.battery_temperature = np.clip(self.battery_temperature, 15.0, 60.0)

    def _update_traffic(self, dt: float):
        """更新前车动力学"""

        # 简单的跟车模型
        desired_gap = 2.0 * self.lead_vehicle_velocity  # 2秒规则
        gap_error = self.lead_vehicle_distance - desired_gap

        # 前车加速度
        self.lead_vehicle_acceleration = 0.1 * gap_error + \
                                         0.01 * (self.velocity - self.lead_vehicle_velocity)

        # 添加随机变化
        self.lead_vehicle_acceleration += np.random.normal(0, 0.1)

        # 更新前车速度
        self.lead_vehicle_velocity = max(0.0,
                                         self.lead_vehicle_velocity +
                                         self.lead_vehicle_acceleration * dt)

        # 更新距离
        relative_velocity = self.velocity - self.lead_vehicle_velocity
        self.lead_vehicle_distance = max(0.0,
                                         self.lead_vehicle_distance +
                                         relative_velocity * dt)

        # 偶尔的车道变更或驶出
        if np.random.rand() < 0.001:  # 每步0.1%概率
            self.lead_vehicle_distance = 50.0 + np.random.uniform(-10, 10)

    def _update_driver_intent(self, dt: float):
        """基于配置文件更新驾驶员制动意图"""

        profile = self.config['driver_profile']

        # 速度误差
        velocity_error = self.velocity - self.target_velocity

        if profile == 'aggressive':
            # 对小误差进行强烈制动
            if velocity_error > 1.0:
                self.braking_intent = min(1.0, 0.5 + 0.5 * velocity_error / 5.0)
            else:
                self.braking_intent = 0.0

        elif profile == 'eco':
            # 带预判的温和制动
            # 前瞻即将到来的停车
            look_ahead_time = 3.0  # 秒
            future_velocity_error = velocity_error + self.acceleration * look_ahead_time

            if future_velocity_error > 0.5:
                self.braking_intent = min(1.0, 0.3 + 0.3 * future_velocity_error / 5.0)
            else:
                self.braking_intent = 0.0

        else:  # 'normal'
            # 中等制动
            if velocity_error > 2.0:
                self.braking_intent = min(1.0, 0.1 + 0.4 * velocity_error / 5.0)
            else:
                self.braking_intent = 0.0

        # 平滑意图变化
        intent_time_constant = 0.5  # 秒
        self.braking_intent = self.braking_intent + \
                              (self.brake_pedal_position - self.braking_intent) * \
                              dt / intent_time_constant

        # 基于意图更新制动踏板位置
        self.brake_pedal_position = self.braking_intent
        self.brake_torque_demand = self.brake_pedal_position * self.config['max_brake_torque']

    def _calculate_reward(self,
                          brake_torque: float,
                          regen_energy: float,
                          kinetic_energy_loss: float) -> float:
        """
        基于多个目标计算奖励（第4.3节）

        r_t = w_e * r_energy + w_s * r_safety + w_c * r_comfort + w_t * r_tracking
        """

        # 1. 能量回收奖励
        if kinetic_energy_loss > 0:
            energy_recovery_efficiency = regen_energy / kinetic_energy_loss
            r_energy = energy_recovery_efficiency
        else:
            r_energy = 0.0

        # 2. 安全奖励
        # 防碰撞
        time_to_collision = (self.lead_vehicle_distance /
                             max(0.1, self.velocity - self.lead_vehicle_velocity))

        if time_to_collision < 0:  # 跟车太近
            r_safety = -10.0
            self.near_collisions += 1
        elif time_to_collision < 2.0:  # 警告区域
            r_safety = -5.0 * (2.0 - time_to_collision)
            self.near_collisions += 0.5
        else:
            r_safety = 0.0

        # 过度减速度惩罚（> 0.3g）
        deceleration = -self.acceleration
        if deceleration > 0.3 * self.config['gravity']:
            r_safety -= 10.0 * (deceleration / (0.3 * self.config['gravity']) - 1.0)
            self.safety_violations += 1

        # 3. 舒适度奖励（加加速度惩罚）
        jerk_magnitude = abs(self.jerk)
        if jerk_magnitude > 10.0:  # > 10 m/s³ 不舒服
            r_comfort = -5.0 * (jerk_magnitude / 10.0 - 1.0)
        else:
            r_comfort = 0.0

        # 4. 驾驶员意图跟踪奖励
        brake_error = abs(self.brake_torque_demand - abs(brake_torque)) / \
                      self.config['max_brake_torque']
        r_tracking = -5.0 * brake_error

        # 5. 速度跟踪奖励
        velocity_error = abs(self.velocity - self.target_velocity) / 5.0
        r_velocity = -2.0 * velocity_error

        # 加权和（匹配论文权重）
        weights = {
            'energy': 0.5,
            'safety': 0.3,
            'comfort': 0.1,
            'tracking': 0.1
        }

        total_reward = (
                weights['energy'] * r_energy +
                weights['safety'] * r_safety +
                weights['comfort'] * r_comfort +
                weights['tracking'] * (r_tracking + r_velocity)
        )

        # 缩放奖励
        total_reward = total_reward * 10.0

        return float(total_reward)

    def _check_termination(self) -> bool:
        """检查回合是否应终止"""

        # 时间限制
        if self.time > 300.0:  # 5分钟回合
            return True

        # 碰撞
        if self.lead_vehicle_distance <= 0.0:
            self.safety_violations += 10
            return True

        # 过多安全违规
        if self.safety_violations > 20:
            return True

        # SOC过低
        if self.soc < 0.1:
            return True

        return False

    def apply_distribution_shift(self, shift_type: str, severity: float = 0.2):
        """
        应用分布偏移以进行鲁棒性测试

        参数：
            shift_type: 'battery_aging', 'sensor_noise', 'driver_behavior', 'road_condition'
            severity: 0.0（无）到 1.0（严重）
        """

        if shift_type == 'battery_aging':
            # 模拟电池退化
            degradation = 1.0 - severity * 0.5  # 最多50%容量损失
            self.config['battery_degradation'] = degradation
            self.battery_params['capacity_degradation_factor'] = degradation

            # 增加内阻
            self.battery_params['internal_resistance'] = \
                self.config['battery_internal_resistance'] * (1.0 + severity)

        elif shift_type == 'sensor_noise':
            # 增加传感器噪声
            self.config['velocity_noise_std'] = 0.02 * (1.0 + severity * 5)
            self.config['soc_noise_std'] = 0.05 * (1.0 + severity * 5)
            self.config['distance_noise_std'] = 0.05 * (1.0 + severity * 5)

        elif shift_type == 'driver_behavior':
            # 更改驾驶员配置文件
            profiles = ['normal', 'aggressive', 'eco']
            new_profile = profiles[int(severity * (len(profiles) - 1))]
            self.config['driver_profile'] = new_profile

        elif shift_type == 'road_condition':
            # 更改道路坡度和滚动阻力
            self.road_grade = severity * 0.1  # 最多10%坡度
            self.config['rolling_resistance'] = 0.01 * (1.0 + severity * 2)

        elif shift_type == 'weather':
            # 更改天气条件
            self.ambient_temperature = 20.0 + severity * 20  # 最多40°C
            self.wind_speed = severity * 10  # 最多10 m/s

        else:
            print(f"未知偏移类型: {shift_type}")
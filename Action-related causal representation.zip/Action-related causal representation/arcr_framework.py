"""
ARCR_Framework.py
动作相关因果表征框架的核心实现
包含所有主要模块：编码器、动力学、策略和完整框架集成
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.distributions as td
import numpy as np
import math
from collections import deque, namedtuple
import itertools
from typing import Tuple, Dict, List, Optional, Union
import time
import warnings

warnings.filterwarnings('ignore')


# ==================== 1. 数学基础与理论框架 ====================

class CausalDoOperator:
    """
    Pearl干预操作符的因果推断实现
    形式化干预分布与观察分布的区别
    """

    def __init__(self, causal_graph: np.ndarray):
        """
        causal_graph: 邻接矩阵，causal_graph[i,j] = 1 表示 i -> j
        """
        self.causal_graph = causal_graph
        self.n_vars = causal_graph.shape[0]

    def intervene(self,
                  variables: List[int],
                  values: np.ndarray,
                  observational_data: np.ndarray) -> np.ndarray:
        """
        应用干预操作符：do(X = x)

        参数：
            variables: 要干预的变量索引
            values: 干预变量的值
            observational_data: 原始数据矩阵 [n_samples, n_vars]

        返回：
            干预分布数据
        """
        interventional_data = observational_data.copy()

        for var, val in zip(variables, values):
            # 将变量设置为干预值
            interventional_data[:, var] = val

            # 切断传入的因果箭头（移除依赖关系）
            # 实践中，这意味着我们以父变量为条件，但不使用变量自身的因果机制

        return interventional_data

    def causal_parents(self, variable: int) -> List[int]:
        """获取变量的因果父节点"""
        return [i for i in range(self.n_vars) if self.causal_graph[i, variable] == 1]

    def causal_children(self, variable: int) -> List[int]:
        """获取变量的因果子节点"""
        return [i for i in range(self.n_vars) if self.causal_graph[variable, i] == 1]


class ActionCausalSufficiency:
    """
    实现定义1：动作因果充分性
    用于测试因果充分性的形式化数学框架
    """

    def __init__(self,
                 representation_dim: int,
                 action_dim: int,
                 reward_dim: int = 1):

        self.repr_dim = representation_dim
        self.action_dim = action_dim
        self.reward_dim = reward_dim

        # 存储条件分布和干预分布
        self.conditional_distributions = {}
        self.interventional_distributions = {}

    def test_sufficiency(self,
                         Z: np.ndarray,  # 表征
                         S: np.ndarray,  # 原始状态
                         A: np.ndarray,  # 动作
                         R: np.ndarray,  # 奖励
                         interventions: List[np.ndarray] = None,
                         alpha: float = 0.05) -> Tuple[bool, float]:
        """
        测试表征Z是否具有动作因果充分性

        返回：
            is_sufficient: 布尔值
            test_statistic: 浮点数（KL散度）
        """

        n_samples = Z.shape[0]

        # 估计条件分布
        # P(R | do(A), Z) 和 P(R | do(A), S)
        conditional_KLs = []

        if interventions is None:
            # 使用观察到的动作作为干预（在探索假设下）
            interventions = [A]

        for intervention in interventions:
            # 对每个动作干预 do(A = a)
            for a_val in np.unique(intervention, axis=0):
                mask = (intervention == a_val).all(axis=1)

                if mask.sum() < 10:  # 需要足够的样本
                    continue

                Z_subset = Z[mask]
                S_subset = S[mask]
                R_subset = R[mask]

                # 估计分布
                # 用于测试的简单高斯近似
                mu_R_given_Z = R_subset.mean()
                sigma_R_given_Z = R_subset.std()

                mu_R_given_S = R_subset.mean()  # 实际上会依赖于S
                sigma_R_given_S = R_subset.std()

                # 计算KL散度
                KL = self._gaussian_kl(mu_R_given_Z, sigma_R_given_Z,
                                       mu_R_given_S, sigma_R_given_S)
                conditional_KLs.append(KL)

        # 测试统计量：最大KL散度
        test_statistic = np.max(conditional_KLs) if conditional_KLs else 0

        # 基于样本量的阈值
        threshold = np.sqrt(2 * np.log(1 / alpha) / n_samples)
        is_sufficient = test_statistic < threshold

        return is_sufficient, test_statistic

    def _gaussian_kl(self, mu1: float, sigma1: float,
                     mu2: float, sigma2: float) -> float:
        """两个高斯分布之间的KL散度"""
        return (np.log(sigma2 / sigma1) +
                (sigma1 ** 2 + (mu1 - mu2) ** 2) / (2 * sigma2 ** 2) - 0.5)


# ==================== 2. 动作相关因果表征模块 ====================

class InterventionConsistentEncoder(nn.Module):
    """
    干预一致因果表征学习的完整实现
    实现第3.4节中的方程(13)-(15)
    """

    def __init__(self,
                 state_dim: int = 22,  # 原始观测维度 d
                 latent_dim: int = 32,  # 因果表征维度 d_z
                 action_dim: int = 1,
                 hidden_dim: int = 256,
                 beta: float = 0.01,  # 信息瓶颈权重
                 lambda_causal: float = 0.1,  # 因果梯度掩码权重
                 causal_prior: Optional[np.ndarray] = None,
                 device: str = 'cuda'):

        super().__init__()

        # 维度
        self.state_dim = state_dim
        self.latent_dim = latent_dim
        self.action_dim = action_dim
        self.hidden_dim = hidden_dim
        self.device = device

        # 超参数
        self.beta = beta
        self.lambda_causal = lambda_causal
        self.temperature = 1.0  # Gumbel-Softmax温度参数

        # 编码器网络：映射 S -> Z
        self.encoder = nn.Sequential(
            nn.Linear(state_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(),
        )

        # VAE的输出头
        self.fc_mean = nn.Linear(hidden_dim, latent_dim)
        self.fc_logvar = nn.Linear(hidden_dim, latent_dim)

        # 因果掩码：M ∈ {0,1}^{d_z × d_s}
        self.causal_mask_weight = nn.Parameter(
            torch.randn(latent_dim, state_dim) * 0.01)

        # 关于因果变量的先验知识（来自车辆物理）
        if causal_prior is not None:
            self.register_buffer('causal_prior', torch.FloatTensor(causal_prior).to(device))
        else:
            # 默认：假设前k个变量是因果的（速度、SOC等）
            prior = torch.zeros(latent_dim, state_dim, device=device)
            for i in range(min(latent_dim, 7)):  # 前7个是物理变量
                prior[i, i] = 1.0
            self.register_buffer('causal_prior', prior)

        # 干预感知层
        self.intervention_projection = nn.Linear(action_dim, hidden_dim)

        # 反事实预测头
        self.counterfactual_predictor = nn.Sequential(
            nn.Linear(latent_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, latent_dim)
        )

        # 移动到指定设备
        self.to(device)

    def forward(self,
                state: torch.Tensor,
                action: Optional[torch.Tensor] = None,
                intervention_type: str = 'observational',
                deterministic: bool = False) -> Dict[str, torch.Tensor]:
        """
        具有干预感知能力的前向传播

        参数：
            state: [batch_size, state_dim]
            action: [batch_size, action_dim]（可选）
            intervention_type: 'observational', 'interventional', 'counterfactual'
            deterministic: 是否采样或使用均值

        返回：
            包含以下内容的字典：
                z: 因果表征
                mean: 编码器均值
                logvar: 编码器对数方差
                mask: 因果掩码
                intervention_effect: 估计的干预效果
        """

        batch_size = state.shape[0]

        # 确保输入在正确的设备上
        state = state.to(self.device)
        if action is not None:
            action = action.to(self.device)

        # 编码状态
        h = self.encoder(state)

        # 如果提供了动作，则纳入干预感知
        if action is not None:
            action_effect = self.intervention_projection(action)
            if intervention_type == 'interventional':
                # 对于干预数据，修改编码
                h = h + action_effect

        # 获取分布参数
        mean = self.fc_mean(h)
        logvar = self.fc_logvar(h)

        # 采样或使用均值
        if deterministic:
            z = mean
        else:
            std = torch.exp(0.5 * logvar)
            eps = torch.randn_like(std)
            z = mean + eps * std

        # 获取因果掩码
        mask = self._get_causal_mask()

        # 应用因果掩码以强制执行稀疏连接
        z_masked = self._apply_causal_mask(z, mask)

        # 如果请求则进行反事实预测
        intervention_effect = None
        if intervention_type == 'counterfactual' and action is not None:
            # 预测在不同动作下的表征
            with torch.no_grad():
                # 获取无干预下的表征
                z_obs = self.forward(state, deterministic=True)['z']

            # 预测反事实
            intervention_effect = self.counterfactual_predictor(
                torch.cat([z_obs, action], dim=-1))
            z_masked = z_masked + intervention_effect

        return {
            'z': z_masked,
            'mean': mean,
            'logvar': logvar,
            'mask': mask,
            'intervention_effect': intervention_effect
        }

    def _get_causal_mask(self) -> torch.Tensor:
        """
        使用Gumbel-Softmax松弛获取因果掩码

        返回：
            mask: [latent_dim, state_dim]，值在[0,1]之间
        """

        if self.training:
            # 用于可微分采样的Gumbel-Softmax松弛
            gumbel_noise = torch.rand_like(self.causal_mask_weight)
            gumbel_noise = -torch.log(-torch.log(gumbel_noise + 1e-8) + 1e-8)

            logits = (self.causal_mask_weight + gumbel_noise) / self.temperature
            mask = torch.sigmoid(logits)
        else:
            # 推理时使用硬掩码
            mask = (self.causal_mask_weight > 0).float()

        # 与先验知识混合（论文中的方程16）
        mask = 0.7 * mask + 0.3 * self.causal_prior

        # 确保非负性
        mask = torch.clamp(mask, 0, 1)

        return mask

    def _apply_causal_mask(self,
                           z: torch.Tensor,
                           mask: torch.Tensor) -> torch.Tensor:
        """
        应用因果掩码以强制执行稀疏因果结构

        参数：
            z: [batch_size, latent_dim]
            mask: [latent_dim, state_dim]

        返回：
            z_masked: [batch_size, latent_dim]
        """

        # 方法1：使用mask作为权重对z进行缩放
        # 计算每个潜在维度的权重（与状态维度的平均连接强度）
        mask_weights = mask.mean(dim=1, keepdim=True)  # [latent_dim, 1]
        z_masked = z * mask_weights.t()  # [batch_size, latent_dim]

        return z_masked

    def compute_losses(self,
                       state: torch.Tensor,
                       action: torch.Tensor,
                       reward: torch.Tensor,
                       next_state: torch.Tensor,
                       reward_predictor: nn.Module,
                       dynamics_model: nn.Module) -> Dict[str, torch.Tensor]:
        """
        计算因果表征学习的所有损失

        实现第3.4节中的方程12：
        L_ARCR = L_reward + β * L_IB + λ * L_causal + L_dyn
        """

        # 确保所有输入在正确的设备上
        state = state.to(self.device)
        action = action.to(self.device)
        reward = reward.to(self.device)
        next_state = next_state.to(self.device)

        # 前向传播
        encoder_output = self.forward(state, action, 'observational')
        z = encoder_output['z']
        mean = encoder_output['mean']
        logvar = encoder_output['logvar']
        mask = encoder_output['mask']

        # 1. 奖励预测损失（方程13）
        reward_pred = reward_predictor(z, action)
        reward_loss = F.mse_loss(reward_pred, reward)

        # 2. 信息瓶颈损失（方程14）
        # q(z|s)和先验p(z)之间的KL散度
        prior = td.Normal(torch.zeros_like(mean), torch.ones_like(mean))
        posterior = td.Normal(mean, torch.exp(0.5 * logvar))

        # KL散度的蒙特卡洛估计
        kl_samples = posterior.rsample((10,))  # 10个样本以获得更好的估计
        log_posterior = posterior.log_prob(kl_samples).sum(dim=-1)
        log_prior = prior.log_prob(kl_samples).sum(dim=-1)
        kl_loss = (log_posterior - log_prior).mean()

        # 3. 因果梯度掩码损失（方程15）
        # 强制执行通过非因果维度的稀疏梯度流

        # 计算表征相对于奖励的梯度
        z.requires_grad_(True)
        reward_pred_grad = reward_predictor(z, action)
        reward_grad = torch.autograd.grad(
            outputs=reward_pred_grad.sum(),
            inputs=z,
            create_graph=True,
            retain_graph=True
        )[0]

        # 对梯度应用掩码
        mask_expanded = mask.unsqueeze(0).expand(z.shape[0], -1, -1)
        z_expanded = z.unsqueeze(-1).expand(-1, -1, self.state_dim)

        # 通过因果结构计算梯度
        causal_grad_loss = torch.mean(
            ((1 - mask_expanded) * reward_grad.unsqueeze(-1)) ** 2
        )

        # 4. 动力学预测损失（确保时间一致性）
        with torch.no_grad():
            next_z = self.forward(next_state, deterministic=True)['z']

        z_next_pred = dynamics_model(z, action)
        dyn_loss = F.mse_loss(z_next_pred, next_z)

        # 5. 因果结构正则化
        # 鼓励与先验知识对齐
        causal_align_loss = F.mse_loss(mask, self.causal_prior)

        # 6. 干预一致性损失
        # 确保表征在干预下保持一致
        interv_output = self.forward(state, action, 'interventional')
        z_interv = interv_output['z']

        # 表征应仅在因果影响的维度上不同
        intervention_consistency_loss = F.mse_loss(z[:, :5], z_interv[:, :5])  # 前5个维度应相同

        # 总损失（方程12）
        total_loss = (reward_loss +
                      self.beta * kl_loss +
                      self.lambda_causal * causal_grad_loss +
                      0.1 * dyn_loss +
                      0.05 * causal_align_loss +
                      0.01 * intervention_consistency_loss)

        return {
            'total_loss': total_loss,
            'reward_loss': reward_loss,
            'kl_loss': kl_loss,
            'causal_grad_loss': causal_grad_loss,
            'dyn_loss': dyn_loss,
            'causal_align_loss': causal_align_loss,
            'intervention_consistency_loss': intervention_consistency_loss,
            'mask_sparsity': (mask < 0.1).float().mean()
        }


# ==================== 3. 结构化潜在动力学模块 ====================

class CausalStructuredDynamics(nn.Module):
    """
    结构化潜在动力学的完整实现
    具有显式因果马尔可夫性质（定义3）

    实现具有因果约束的时间演化：
    P(Z_{t+1} | do(A_t), Z_t, H_{t-1}) = P(Z_{t+1} | do(A_t), Z_t)
    """

    def __init__(self,
                 latent_dim: int = 32,
                 action_dim: int = 1,
                 hidden_dim: int = 256,
                 gru_layers: int = 2,
                 use_causal_transitions: bool = True,
                 device: str = 'cuda'):

        super().__init__()

        self.latent_dim = latent_dim
        self.action_dim = action_dim
        self.hidden_dim = hidden_dim
        self.use_causal_transitions = use_causal_transitions
        self.device = device

        # 用于时间动力学的GRU，带有因果掩码
        self.gru = nn.GRU(
            input_size=latent_dim + action_dim,
            hidden_size=hidden_dim,
            num_layers=gru_layers,
            batch_first=True,
            dropout=0.1 if gru_layers > 1 else 0
        )

        # 因果转移矩阵：T ∈ R^{d_z × d_z}
        # T[i,j] 表示z_j对z_i的因果影响
        self.transition_matrix = nn.Parameter(
            torch.eye(latent_dim) * 0.5 +
            torch.randn(latent_dim, latent_dim) * 0.01
        )

        # 动力学预测网络
        self.dynamics_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, latent_dim * 2)  # 均值和对数方差
        )

        # 干预感知动力学
        self.intervention_encoder = nn.Sequential(
            nn.Linear(action_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, latent_dim)
        )

        # 奖励预测器（因果结构化）
        self.reward_predictor = nn.Sequential(
            nn.Linear(latent_dim + action_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1)
        )

        # 隐藏状态初始化
        self.hidden_state = None

        # 移动到指定设备
        self.to(device)

    def forward(self,
                z_t: torch.Tensor,
                a_t: torch.Tensor,
                h_t: Optional[torch.Tensor] = None,
                intervention_flag: bool = False) -> Dict[str, torch.Tensor]:
        """
        使用因果结构预测下一个潜在状态

        参数：
            z_t: 当前潜在状态 [batch_size, latent_dim]
            a_t: 动作 [batch_size, action_dim]
            h_t: 先前隐藏状态 [gru_layers, batch_size, hidden_dim]
            intervention_flag: 动作是否为干预性

        返回：
            包含预测的字典
        """

        batch_size = z_t.shape[0]

        # 确保输入在正确的设备上
        z_t = z_t.to(self.device)
        a_t = a_t.to(self.device)
        if h_t is not None:
            h_t = h_t.to(self.device)

        # 编码当前状态和动作
        gru_input = torch.cat([z_t, a_t], dim=-1).unsqueeze(1)  # 添加序列维度

        # GRU前向传播
        gru_out, h_next = self.gru(gru_input, h_t)
        gru_out = gru_out.squeeze(1)  # 移除序列维度

        # 预测下一个状态分布
        dynamics_out = self.dynamics_head(gru_out)
        z_mean_pred = dynamics_out[:, :self.latent_dim]
        z_logvar_pred = dynamics_out[:, self.latent_dim:]

        # 应用因果转移矩阵
        if self.use_causal_transitions:
            # 用于因果性的软阈值转移矩阵
            T = torch.sigmoid(self.transition_matrix * 5)  # 锐化sigmoid

            # 应用因果转移：z_{t+1} = T * f(z_t, a_t)
            z_mean_pred = z_mean_pred @ T
            z_logvar_pred = z_logvar_pred @ T.abs()  # 确保正性

        # 如果指定则添加干预效果
        if intervention_flag:
            intervention_effect = self.intervention_encoder(a_t)
            z_mean_pred = z_mean_pred + intervention_effect

        # 采样下一个状态
        z_std_pred = torch.exp(0.5 * z_logvar_pred)
        eps = torch.randn_like(z_std_pred)
        z_next_pred = z_mean_pred + eps * z_std_pred

        # 预测奖励
        reward_input = torch.cat([z_t, a_t], dim=-1)
        r_pred = self.reward_predictor(reward_input)

        # 为下一步存储隐藏状态
        self.hidden_state = h_next

        return {
            'z_next_pred': z_next_pred,
            'z_mean_pred': z_mean_pred,
            'z_logvar_pred': z_logvar_pred,
            'r_pred': r_pred,
            'h_next': h_next
        }

    def compute_losses(self,
                       z_t: torch.Tensor,
                       a_t: torch.Tensor,
                       z_tp1_true: torch.Tensor,
                       r_t_true: torch.Tensor,
                       causal_mask: Optional[torch.Tensor] = None) -> Dict[str, torch.Tensor]:
        """
        计算动力学预测损失

        参数：
            z_t: 当前潜在状态
            a_t: 动作
            z_tp1_true: 真实的下一个潜在状态
            r_t_true: 真实奖励
            causal_mask: 因果结构正则化的掩码

        返回：
            损失字典
        """

        # 确保所有输入在正确的设备上
        z_t = z_t.to(self.device)
        a_t = a_t.to(self.device)
        z_tp1_true = z_tp1_true.to(self.device)
        r_t_true = r_t_true.to(self.device)
        if causal_mask is not None:
            causal_mask = causal_mask.to(self.device)

        # 前向预测
        pred_dict = self.forward(z_t, a_t)
        z_tp1_pred = pred_dict['z_next_pred']
        z_mean_pred = pred_dict['z_mean_pred']
        z_logvar_pred = pred_dict['z_logvar_pred']
        r_pred = pred_dict['r_pred']

        # 1. 动力学预测损失（MSE）
        dynamics_loss = F.mse_loss(z_tp1_pred, z_tp1_true)

        # 2. 负对数似然（高斯）
        z_std_pred = torch.exp(0.5 * z_logvar_pred)
        nll_loss = 0.5 * torch.mean(
            z_logvar_pred + ((z_tp1_true - z_mean_pred) ** 2) / (z_std_pred ** 2 + 1e-8)
        )

        # 3. 奖励预测损失
        reward_loss = F.mse_loss(r_pred, r_t_true)

        # 4. 因果结构正则化
        if causal_mask is not None and self.use_causal_transitions:
            # 转移矩阵应尊重因果掩码
            T = torch.sigmoid(self.transition_matrix * 5)
            causal_structure_loss = F.mse_loss(
                T[:causal_mask.shape[0], :causal_mask.shape[1]],
                causal_mask.T  # 转置以匹配维度
            )
        else:
            causal_structure_loss = torch.tensor(0.0, device=self.device)

        # 5. 时间一致性损失
        # 鼓励平滑转移
        delta_pred = z_tp1_pred - z_t
        delta_true = z_tp1_true - z_t
        temporal_loss = F.mse_loss(delta_pred, delta_true)

        # 6. 稀疏转移正则化
        # 鼓励稀疏因果图
        if self.use_causal_transitions:
            T = torch.sigmoid(self.transition_matrix * 5)
            sparsity_loss = torch.mean(torch.abs(T))
        else:
            sparsity_loss = torch.tensor(0.0, device=self.device)

        # 总损失
        total_loss = (dynamics_loss +
                      0.5 * nll_loss +
                      reward_loss +
                      0.1 * causal_structure_loss +
                      0.05 * temporal_loss +
                      0.01 * sparsity_loss)

        return {
            'total_loss': total_loss,
            'dynamics_loss': dynamics_loss,
            'nll_loss': nll_loss,
            'reward_loss': reward_loss,
            'causal_structure_loss': causal_structure_loss,
            'temporal_loss': temporal_loss,
            'sparsity_loss': sparsity_loss,
            'transition_sparsity': (torch.sigmoid(self.transition_matrix * 5) < 0.1).float().mean()
        }

    def reset_hidden_state(self, batch_size: int = 1):
        """重置GRU隐藏状态"""
        self.hidden_state = torch.zeros(
            self.gru.num_layers, batch_size, self.hidden_dim, device=self.device
        )


# ==================== 4. 因果策略优化模块 ====================

class CausalMaximumEntropyPolicy(nn.Module):
    """
    在学习的表征空间中具有因果约束的最大熵actor-critic完整实现

    实现定理1：策略最优性的因果保持
    """

    def __init__(self,
                 latent_dim: int = 32,
                 action_dim: int = 1,
                 action_limit: float = 100.0,  # 最大制动力矩
                 hidden_dim: int = 256,
                 gamma: float = 0.99,
                 tau: float = 0.005,
                 alpha: float = 0.2,  # 熵温度
                 use_causal_constraints: bool = True,
                 device: str = 'cuda'):

        super().__init__()

        self.latent_dim = latent_dim
        self.action_dim = action_dim
        self.action_limit = action_limit
        self.hidden_dim = hidden_dim
        self.gamma = gamma
        self.tau = tau
        self.alpha = alpha
        self.use_causal_constraints = use_causal_constraints
        self.device = device

        # Actor网络（策略）π(a|z)
        self.actor = nn.Sequential(
            nn.Linear(latent_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(),
        )

        # 均值和log std的输出头
        self.actor_mean = nn.Linear(hidden_dim, action_dim)
        self.actor_logstd = nn.Linear(hidden_dim, action_dim)

        # 初始化有界动作的actor输出
        self.actor_mean.weight.data.uniform_(-1e-3, 1e-3)
        self.actor_logstd.weight.data.uniform_(-1e-3, 1e-3)

        # 双critic Q1(z,a) 和 Q2(z,a)
        self.critic1 = self._build_critic()
        self.critic2 = self._build_critic()

        # 目标网络
        self.critic1_target = self._build_critic()
        self.critic2_target = self._build_critic()
        self._hard_update(self.critic1, self.critic1_target)
        self._hard_update(self.critic2, self.critic2_target)

        # 因果动作掩码：鼓励策略仅使用因果维度
        self.causal_action_mask = nn.Parameter(torch.ones(latent_dim))

        # 自动熵调整
        self.target_entropy = -torch.prod(torch.Tensor([action_dim])).item()
        self.log_alpha = nn.Parameter(torch.zeros(1))

        # 干预感知价值函数
        self.intervention_value_head = nn.Sequential(
            nn.Linear(latent_dim + action_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1)
        )

        # 移动到指定设备
        self.to(device)

    def _build_critic(self) -> nn.Module:
        """构建critic网络"""
        return nn.Sequential(
            nn.Linear(self.latent_dim + self.action_dim, self.hidden_dim),
            nn.LayerNorm(self.hidden_dim),
            nn.ReLU(),
            nn.Linear(self.hidden_dim, self.hidden_dim),
            nn.LayerNorm(self.hidden_dim),
            nn.ReLU(),
            nn.Linear(self.hidden_dim, self.hidden_dim),
            nn.LayerNorm(self.hidden_dim),
            nn.ReLU(),
            nn.Linear(self.hidden_dim, 1)
        )

    def _hard_update(self, source: nn.Module, target: nn.Module):
        """硬更新目标网络"""
        target.load_state_dict(source.state_dict())

    def forward(self,
                z: torch.Tensor,
                deterministic: bool = False,
                with_logprob: bool = True,
                intervention_type: str = 'observational') -> Dict[str, torch.Tensor]:
        """
        通过策略网络前向传播

        参数：
            z: 因果表征 [batch_size, latent_dim]
            deterministic: 是否采样或使用均值
            with_logprob: 是否计算对数概率
            intervention_type: 干预类型

        返回：
            包含动作和相关信息的字典
        """

        batch_size = z.shape[0]
        z = z.to(self.device)  # 确保输入在正确的设备上

        # 应用因果动作掩码
        if self.use_causal_constraints:
            z_masked = z * torch.sigmoid(self.causal_action_mask).unsqueeze(0)
        else:
            z_masked = z

        # 通过actor前向传播
        actor_features = self.actor(z_masked)

        # 获取均值和log std
        mean = self.actor_mean(actor_features)
        log_std = self.actor_logstd(actor_features)

        # 为数值稳定性限制log std
        log_std = torch.clamp(log_std, -20, 2)
        std = torch.exp(log_std)

        # 创建高斯分布
        dist = td.Normal(mean, std)

        # 采样或使用均值
        if deterministic:
            pi_action = mean
        else:
            pi_action = dist.rsample()  # 重参数化采样

        # 应用tanh压缩以限制动作
        pi_action_tanh = torch.tanh(pi_action)
        pi_action_scaled = pi_action_tanh * self.action_limit

        # 使用tanh变换计算对数概率
        if with_logprob:
            # 原始对数概率
            logp_pi = dist.log_prob(pi_action).sum(dim=-1)

            # tanh压缩的修正（log |det(J)|）
            logp_pi -= (2 * (np.log(2) - pi_action - F.softplus(-2 * pi_action))).sum(dim=-1)

            # 熵
            entropy = dist.entropy().sum(dim=-1)
        else:
            logp_pi = torch.zeros(batch_size, device=self.device)
            entropy = torch.zeros(batch_size, device=self.device)

        # 获取Q值
        q1, q2 = self.get_q_values(z, pi_action_scaled)
        min_q = torch.min(q1, q2)

        # 如果需要，干预感知价值
        if intervention_type == 'interventional':
            intervention_value = self.intervention_value_head(
                torch.cat([z, pi_action_scaled], dim=-1))
        else:
            intervention_value = torch.zeros_like(min_q)

        return {
            'action': pi_action_scaled,
            'mean': mean,
            'log_std': log_std,
            'log_prob': logp_pi,
            'entropy': entropy,
            'q1': q1,
            'q2': q2,
            'min_q': min_q,
            'intervention_value': intervention_value,
            'z_masked': z_masked
        }

    def get_q_values(self,
                     z: torch.Tensor,
                     a: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        从双critic获取Q值

        参数：
            z: 因果表征
            a: 动作

        返回：
            q1, q2: 两个critic的Q值
        """

        # 确保输入在正确的设备上
        z = z.to(self.device)
        a = a.to(self.device)

        # 应用因果掩码
        if self.use_causal_constraints:
            z_masked = z * torch.sigmoid(self.causal_action_mask).unsqueeze(0)
        else:
            z_masked = z

        sa = torch.cat([z_masked, a], dim=-1)

        q1 = self.critic1(sa)
        q2 = self.critic2(sa)

        return q1, q2

    def get_target_q_values(self,
                            z: torch.Tensor,
                            a: torch.Tensor) -> torch.Tensor:
        """
        获取目标Q值（裁剪双Q学习）
        """

        # 确保输入在正确的设备上
        z = z.to(self.device)
        a = a.to(self.device)

        # 应用因果掩码
        if self.use_causal_constraints:
            z_masked = z * torch.sigmoid(self.causal_action_mask).unsqueeze(0)
        else:
            z_masked = z

        sa = torch.cat([z_masked, a], dim=-1)

        q1 = self.critic1_target(sa)
        q2 = self.critic2_target(sa)

        # 裁剪双Q学习
        return torch.min(q1, q2)

    def compute_losses(self,
                       z: torch.Tensor,
                       a: torch.Tensor,
                       r: torch.Tensor,
                       z_next: torch.Tensor,
                       done: torch.Tensor,
                       causal_mask: Optional[torch.Tensor] = None) -> Dict[str, torch.Tensor]:
        """
        计算所有策略优化损失

        实现具有因果约束的最大熵actor-critic
        """

        # 确保所有输入在正确的设备上
        z = z.to(self.device)
        a = a.to(self.device)
        r = r.to(self.device)
        z_next = z_next.to(self.device)
        done = done.to(self.device)
        if causal_mask is not None:
            causal_mask = causal_mask.to(self.device)

        batch_size = z.shape[0]

        # ========== Critic损失 ==========
        with torch.no_grad():
            # 从当前策略获取下一个动作
            next_action_dict = self.forward(z_next, deterministic=False)
            next_action = next_action_dict['action']
            next_log_prob = next_action_dict['log_prob']

            # 目标Q值
            target_q = self.get_target_q_values(z_next, next_action)

            # 软贝尔曼备份
            target_q_backup = r + self.gamma * (1 - done) * (
                    target_q - self.alpha * next_log_prob.unsqueeze(-1)
            )

        # 当前Q值
        current_q1, current_q2 = self.get_q_values(z, a)

        # Critic损失
        critic1_loss = F.mse_loss(current_q1, target_q_backup)
        critic2_loss = F.mse_loss(current_q2, target_q_backup)

        # ========== Actor损失 ==========
        # 从当前策略获取动作
        pi_dict = self.forward(z, deterministic=False)
        pi_action = pi_dict['action']
        pi_log_prob = pi_dict['log_prob']

        # 当前策略的Q值
        q1_pi, q2_pi = self.get_q_values(z, pi_action)
        min_q_pi = torch.min(q1_pi, q2_pi)

        # 带熵正则化的actor损失
        actor_loss = (self.alpha * pi_log_prob.unsqueeze(-1) - min_q_pi).mean()

        # ========== 因果约束损失 ==========
        if self.use_causal_constraints:
            # 鼓励潜在维度的稀疏使用
            causal_mask_weights = torch.sigmoid(self.causal_action_mask)

            # 稀疏性正则化
            causal_sparsity_loss = torch.mean(causal_mask_weights)

            # 与编码器的因果掩码对齐
            if causal_mask is not None:
                mask_similarity = F.cosine_similarity(
                    causal_mask_weights.unsqueeze(0),
                    causal_mask.mean(dim=1).unsqueeze(0)
                )
                causal_align_loss = 1 - mask_similarity.mean()
            else:
                causal_align_loss = torch.tensor(0.0, device=self.device)

            # 总因果损失
            causal_loss = 0.01 * causal_sparsity_loss + 0.05 * causal_align_loss
        else:
            causal_loss = torch.tensor(0.0, device=self.device)
            causal_sparsity_loss = torch.tensor(0.0, device=self.device)
            causal_align_loss = torch.tensor(0.0, device=self.device)

        # ========== 熵温度损失 ==========
        # 自动熵调整
        alpha_loss = -(self.log_alpha * (pi_log_prob + self.target_entropy).detach()).mean()
        alpha = self.log_alpha.exp()

        # ========== 总损失 ==========
        critic_loss = critic1_loss + critic2_loss
        total_loss = actor_loss + critic_loss + causal_loss + alpha_loss

        return {
            'total_loss': total_loss,
            'actor_loss': actor_loss,
            'critic_loss': critic_loss,
            'critic1_loss': critic1_loss,
            'critic2_loss': critic2_loss,
            'causal_loss': causal_loss,
            'causal_sparsity_loss': causal_sparsity_loss,
            'causal_align_loss': causal_align_loss,
            'alpha_loss': alpha_loss,
            'alpha': alpha,
            'pi_log_prob': pi_log_prob.mean(),
            'q1_mean': current_q1.mean(),
            'q2_mean': current_q2.mean(),
            'causal_mask_sparsity': (torch.sigmoid(self.causal_action_mask) < 0.1).float().mean()
        }

    def update_target_networks(self):
        """软更新目标网络"""
        for param, target_param in zip(self.critic1.parameters(),
                                       self.critic1_target.parameters()):
            target_param.data.copy_(
                self.tau * param.data + (1 - self.tau) * target_param.data
            )

        for param, target_param in zip(self.critic2.parameters(),
                                       self.critic2_target.parameters()):
            target_param.data.copy_(
                self.tau * param.data + (1 - self.tau) * target_param.data
            )


# ==================== 5. 完整ARCR框架集成 ====================

class ARCRFrameworkComplete:
    """
    所有ARCR组件的完整集成
    实现完整的因果闭环训练机制（第4.4节）
    """

    def __init__(self,
                 state_dim: int = 22,  # 修改为22以匹配实际观测维度
                 action_dim: int = 1,
                 latent_dim: int = 32,
                 action_limit: float = 100.0,
                 device: str = 'cuda' if torch.cuda.is_available() else 'cpu',
                 use_causal_constraints: bool = True):

        print("=" * 80)
        print("ARCR完整实现")
        print("动作相关因果表征框架")
        print(f"状态维度: {state_dim}, 潜在维度: {latent_dim}, 动作维度: {action_dim}")
        print(f"设备: {device}")
        print("=" * 80)

        self.state_dim = state_dim
        self.action_dim = action_dim
        self.latent_dim = latent_dim
        self.action_limit = action_limit
        self.device = device
        self.use_causal_constraints = use_causal_constraints

        # ========== 初始化所有模块 ==========
        print("\n初始化ARCR模块...")

        # 1. 干预一致因果编码器
        self.encoder = InterventionConsistentEncoder(
            state_dim=state_dim,
            latent_dim=latent_dim,
            action_dim=action_dim,
            beta=0.01,  # 信息瓶颈权重
            lambda_causal=0.1,  # 因果梯度掩码权重
            device=device
        ).to(device)

        # 2. 结构化潜在动力学
        self.dynamics = CausalStructuredDynamics(
            latent_dim=latent_dim,
            action_dim=action_dim,
            use_causal_transitions=use_causal_constraints,
            device=device
        ).to(device)

        # 3. 因果最大熵策略
        self.policy = CausalMaximumEntropyPolicy(
            latent_dim=latent_dim,
            action_dim=action_dim,
            action_limit=action_limit,
            use_causal_constraints=use_causal_constraints,
            device=device
        ).to(device)

        # ========== 优化器 ==========
        self.encoder_opt = torch.optim.Adam(
            self.encoder.parameters(), lr=3e-4, weight_decay=1e-5)

        self.dynamics_opt = torch.optim.Adam(
            self.dynamics.parameters(), lr=3e-4, weight_decay=1e-5)

        self.policy_opt = torch.optim.Adam(
            self.policy.parameters(), lr=3e-4, weight_decay=1e-5)

        # ========== 回放缓冲区 ==========
        self.replay_buffer = deque(maxlen=1000000)
        self.transition = namedtuple(
            'Transition',
            ['state', 'action', 'reward', 'next_state', 'done', 'intervention_flag']
        )

        # ========== 训练参数 ==========
        self.gamma = 0.99
        self.tau = 0.005
        self.batch_size = 256
        self.learning_starts = 5000
        self.train_frequency = 4
        self.target_update_frequency = 1000

        # ========== 训练统计 ==========
        self.total_steps = 0
        self.episode = 0
        self.train_stats = {
            'reward': [],
            'actor_loss': [],
            'critic_loss': [],
            'encoder_loss': [],
            'dynamics_loss': [],
            'causal_sparsity': [],
            'energy_recovery': []
        }

        # ========== 因果分析 ==========
        self.causal_structure_history = []

        print("\nARCR框架初始化成功！")
        print(f"编码器参数: {sum(p.numel() for p in self.encoder.parameters()):,}")
        print(f"动力学参数: {sum(p.numel() for p in self.dynamics.parameters()):,}")
        print(f"策略参数: {sum(p.numel() for p in self.policy.parameters()):,}")
        print("=" * 80)

    def store_transition(self,
                         state: np.ndarray,
                         action: np.ndarray,
                         reward: float,
                         next_state: np.ndarray,
                         done: bool,
                         intervention_flag: bool = False):
        """在回放缓冲区中存储转移"""
        self.replay_buffer.append(
            self.transition(state, action, reward, next_state, done, intervention_flag)
        )

    def sample_batch(self, batch_size: int):
        """从回放缓冲区采样批次"""
        indices = np.random.randint(0, len(self.replay_buffer), size=batch_size)
        batch = [self.replay_buffer[i] for i in indices]

        # 解包批次
        states = torch.FloatTensor(np.array([b.state for b in batch])).to(self.device)
        actions = torch.FloatTensor(np.array([b.action for b in batch])).to(self.device)
        rewards = torch.FloatTensor(np.array([b.reward for b in batch])).to(self.device).unsqueeze(-1)
        next_states = torch.FloatTensor(np.array([b.next_state for b in batch])).to(self.device)
        dones = torch.FloatTensor(np.array([b.done for b in batch])).to(self.device).unsqueeze(-1)
        intervention_flags = torch.BoolTensor(np.array([b.intervention_flag for b in batch])).to(self.device)

        return states, actions, rewards, next_states, dones, intervention_flags

    def train_step(self) -> Dict[str, float]:
        """
        具有三阶段闭环训练的单步训练（第4.4节）

        阶段1：表征和动力学学习
        阶段2：策略优化
        阶段3：因果结构优化
        """

        if len(self.replay_buffer) < self.learning_starts:
            return {}

        # 采样批次
        s, a, r, s_next, done, intervention_flags = self.sample_batch(self.batch_size)

        # ========== 阶段1：表征和动力学学习 ==========
        self.encoder_opt.zero_grad()
        self.dynamics_opt.zero_grad()

        # 编码状态
        encoder_output = self.encoder(s, a, 'observational')
        z = encoder_output['z']
        mask = encoder_output['mask']

        # 编码下一个状态
        with torch.no_grad():
            encoder_output_next = self.encoder(s_next, deterministic=True)
            z_next = encoder_output_next['z']

        # 训练动力学模型
        dynamics_losses = self.dynamics.compute_losses(z, a, z_next, r, mask)

        # 训练编码器
        encoder_losses = self.encoder.compute_losses(
            s, a, r, s_next,
            lambda z, a: self.dynamics.reward_predictor(torch.cat([z, a], dim=-1)),
            lambda z, a: self.dynamics(z, a)['z_next_pred']
        )

        # 阶段1的反向传播
        phase1_loss = encoder_losses['total_loss'] + dynamics_losses['total_loss']
        phase1_loss.backward()

        # 梯度裁剪
        torch.nn.utils.clip_grad_norm_(self.encoder.parameters(), max_norm=1.0)
        torch.nn.utils.clip_grad_norm_(self.dynamics.parameters(), max_norm=1.0)

        self.encoder_opt.step()
        self.dynamics_opt.step()

        # ========== 阶段2：策略优化 ==========
        self.policy_opt.zero_grad()

        # 使用更新的编码器重新编码（策略训练时分离）
        with torch.no_grad():
            encoder_output = self.encoder(s, deterministic=True)
            z = encoder_output['z']
            encoder_output_next = self.encoder(s_next, deterministic=True)
            z_next = encoder_output_next['z']
            mask = encoder_output['mask']

        # 训练策略
        policy_losses = self.policy.compute_losses(z, a, r, z_next, done, mask)

        # 阶段2的反向传播
        policy_losses['total_loss'].backward()

        # 梯度裁剪
        torch.nn.utils.clip_grad_norm_(self.policy.parameters(), max_norm=1.0)

        self.policy_opt.step()

        # 更新目标网络
        if self.total_steps % self.target_update_frequency == 0:
            self.policy.update_target_networks()

        # ========== 阶段3：因果结构优化 ==========
        # Gumbel-Softmax温度退火
        if self.total_steps % 100 == 0:
            self.encoder.temperature = max(0.1, self.encoder.temperature * 0.995)

        # 存储因果结构
        if self.total_steps % 1000 == 0:
            causal_info = self.get_causal_structure()
            self.causal_structure_history.append(causal_info)

        self.total_steps += 1

        # 收集统计信息
        stats = {
            'encoder_total_loss': encoder_losses['total_loss'].item(),
            'encoder_reward_loss': encoder_losses['reward_loss'].item(),
            'encoder_kl_loss': encoder_losses['kl_loss'].item(),
            'encoder_causal_grad_loss': encoder_losses['causal_grad_loss'].item(),
            'encoder_mask_sparsity': encoder_losses['mask_sparsity'].item(),

            'dynamics_total_loss': dynamics_losses['total_loss'].item(),
            'dynamics_pred_loss': dynamics_losses['dynamics_loss'].item(),
            'dynamics_reward_loss': dynamics_losses['reward_loss'].item(),
            'dynamics_transition_sparsity': dynamics_losses['transition_sparsity'].item(),

            'policy_total_loss': policy_losses['total_loss'].item(),
            'policy_actor_loss': policy_losses['actor_loss'].item(),
            'policy_critic_loss': policy_losses['critic_loss'].item(),
            'policy_causal_loss': policy_losses['causal_loss'].item(),
            'policy_alpha': policy_losses['alpha'].item(),
            'policy_causal_mask_sparsity': policy_losses['causal_mask_sparsity'].item(),

            'total_steps': self.total_steps
        }

        return stats

    def select_action(self,
                      state: np.ndarray,
                      deterministic: bool = False,
                      exploration_noise: float = 0.1) -> np.ndarray:
        """
        使用因果策略选择动作

        参数：
            state: 当前状态
            deterministic: 是否使用确定性策略
            exploration_noise: 探索噪声的标准差

        返回：
            action: 选择的动作
        """

        state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device)

        with torch.no_grad():
            # 编码状态
            encoder_output = self.encoder(state_tensor, deterministic=True)
            z = encoder_output['z']

            # 从策略获取动作
            action_dict = self.policy(z, deterministic=deterministic)
            action = action_dict['action'].cpu().numpy()[0]

            # 添加探索噪声
            if not deterministic and self.total_steps > self.learning_starts:
                noise = np.random.normal(0, exploration_noise, size=self.action_dim)
                action = np.clip(action + noise, -self.action_limit, 0)

        return action

    def train_episode(self, env, max_steps: int = 1000) -> Dict[str, float]:
        """
        训练一个完整回合

        返回：
            回合统计信息
        """

        state = env.reset()
        episode_reward = 0
        episode_steps = 0
        energy_recovered = 0

        # 重置动力学隐藏状态
        self.dynamics.reset_hidden_state()

        for step in range(max_steps):
            # 选择动作
            exploration_noise = max(0.05, 0.1 * (1 - self.total_steps / 100000))
            action = self.select_action(
                state,
                deterministic=False,
                exploration_noise=exploration_noise
            )

            # 执行动作
            next_state, reward, done, info = env.step(action)

            # 从info中获取能量回收
            if 'energy_recovered' in info:
                energy_recovered += info['energy_recovered']
            else:
                # 简化计算
                if action[0] < 0 and hasattr(env, 'velocity') and env.velocity > 0:
                    energy = abs(action[0]) * env.velocity * 0.1 * 0.85 / 1000
                    energy_recovered += energy

            # 存储转移
            self.store_transition(
                state, action, reward, next_state, done,
                intervention_flag=False
            )

            # 训练
            if self.total_steps >= self.learning_starts:
                if step % self.train_frequency == 0:
                    stats = self.train_step()

                    if step % 100 == 0 and stats:
                        print(f"步骤 {self.total_steps}: "
                              f"奖励={reward:.3f}, "
                              f"Actor损失={stats.get('policy_actor_loss', 0):.3f}, "
                              f"因果稀疏性={stats.get('encoder_mask_sparsity', 0):.3f}")

            state = next_state
            episode_reward += reward
            episode_steps += 1

            if done:
                break

        # 更新统计信息
        self.episode += 1

        # 计算能量回收效率 - 使用正确的质量属性
        if hasattr(env, 'velocity') and hasattr(env, 'config') and env.velocity > 0:
            total_braking_energy = 0.5 * env.config['mass'] * env.velocity ** 2 * 1e-6
            if total_braking_energy > 0:
                energy_recovery_efficiency = energy_recovered / total_braking_energy
            else:
                energy_recovery_efficiency = 0
        else:
            total_braking_energy = 0
            energy_recovery_efficiency = 0

        episode_stats = {
            'episode': self.episode,
            'total_steps': self.total_steps,
            'episode_reward': episode_reward,
            'episode_length': episode_steps,
            'energy_recovered': energy_recovered,
            'energy_recovery_efficiency': energy_recovery_efficiency,
            'average_velocity': env.velocity if hasattr(env, 'velocity') else 0
        }

        # 存储在历史记录中
        for key, value in episode_stats.items():
            if key in self.train_stats:
                self.train_stats[key].append(value)

        return episode_stats

    def evaluate(self,
                 env,
                 n_episodes: int = 5,
                 deterministic: bool = True) -> Dict[str, np.ndarray]:
        """
        评估策略性能

        返回：
            评估统计信息
        """

        episode_rewards = []
        episode_lengths = []
        energy_efficiencies = []
        safety_violations = []

        for ep in range(n_episodes):
            state = env.reset()
            episode_reward = 0
            episode_steps = 0
            energy_recovered = 0
            safety_violation_count = 0

            # 重置动力学隐藏状态
            self.dynamics.reset_hidden_state()

            done = False
            while not done:
                # 确定性选择动作
                action = self.select_action(state, deterministic=deterministic)

                # 执行动作
                next_state, reward, done, info = env.step(action)

                # 计算能量回收
                if 'energy_recovered' in info:
                    energy_recovered += info['energy_recovered']
                else:
                    # 简化计算
                    if action[0] < 0 and hasattr(env, 'velocity') and env.velocity > 0:
                        energy = abs(action[0]) * env.velocity * 0.1 * 0.85 / 1000
                        energy_recovered += energy

                # 检查安全违规（简化）
                if hasattr(env, 'velocity') and env.velocity < 0:
                    safety_violation_count += 1
                if abs(action[0]) > self.action_limit * 1.1:
                    safety_violation_count += 1

                state = next_state
                episode_reward += reward
                episode_steps += 1

            # 计算能量回收效率
            if hasattr(env, 'velocity') and hasattr(env, 'config') and env.velocity > 0:
                total_braking_energy = 0.5 * env.config['mass'] * env.velocity ** 2 * 1e-6
                if total_braking_energy > 0:
                    efficiency = energy_recovered / total_braking_energy
                else:
                    efficiency = 0
            else:
                efficiency = 0

            episode_rewards.append(episode_reward)
            episode_lengths.append(episode_steps)
            energy_efficiencies.append(efficiency)
            safety_violations.append(safety_violation_count)

        stats = {
            'mean_reward': np.mean(episode_rewards),
            'std_reward': np.std(episode_rewards),
            'mean_length': np.mean(episode_lengths),
            'mean_efficiency': np.mean(energy_efficiencies),
            'std_efficiency': np.std(energy_efficiencies),
            'mean_safety_violations': np.mean(safety_violations),
            'episode_rewards': episode_rewards,
            'energy_efficiencies': energy_efficiencies
        }

        return stats

    def get_causal_structure(self) -> Dict[str, np.ndarray]:
        """
        提取和分析因果结构

        返回：
            因果结构信息
        """

        # 获取编码器因果掩码
        with torch.no_grad():
            mask = self.encoder._get_causal_mask().cpu().numpy()

        # 获取策略因果掩码
        policy_mask = torch.sigmoid(self.policy.causal_action_mask).detach().cpu().numpy()

        # 获取动力学转移矩阵
        if self.dynamics.use_causal_transitions:
            T = torch.sigmoid(self.dynamics.transition_matrix * 5).detach().cpu().numpy()
        else:
            T = np.eye(self.latent_dim)

        # 分析因果结构
        causal_scores = mask.mean(axis=0)
        causal_indices = np.where(causal_scores > 0.5)[0]

        # 与先验的一致性
        prior_alignment = np.mean(
            (mask > 0.5) == (self.encoder.causal_prior.cpu().numpy() > 0.5)
        )

        return {
            'encoder_mask': mask,
            'policy_mask': policy_mask,
            'transition_matrix': T,
            'causal_scores': causal_scores,
            'causal_indices': causal_indices,
            'sparsity': (mask < 0.1).mean(),
            'prior_alignment': prior_alignment,
            'step': self.total_steps
        }

    def save_checkpoint(self, path: str):
        """保存完整模型检查点"""

        checkpoint = {
            'encoder_state_dict': self.encoder.state_dict(),
            'dynamics_state_dict': self.dynamics.state_dict(),
            'policy_state_dict': self.policy.state_dict(),

            'encoder_opt_state_dict': self.encoder_opt.state_dict(),
            'dynamics_opt_state_dict': self.dynamics_opt.state_dict(),
            'policy_opt_state_dict': self.policy_opt.state_dict(),

            'total_steps': self.total_steps,
            'episode': self.episode,
            'train_stats': self.train_stats,
            'causal_structure_history': self.causal_structure_history,

            'config': {
                'state_dim': self.state_dim,
                'action_dim': self.action_dim,
                'latent_dim': self.latent_dim,
                'action_limit': self.action_limit,
                'use_causal_constraints': self.use_causal_constraints
            }
        }

        torch.save(checkpoint, path)
        print(f"检查点已保存到 {path}")

    def load_checkpoint(self, path: str):
        """加载模型检查点"""

        checkpoint = torch.load(path, map_location=self.device)

        self.encoder.load_state_dict(checkpoint['encoder_state_dict'])
        self.dynamics.load_state_dict(checkpoint['dynamics_state_dict'])
        self.policy.load_state_dict(checkpoint['policy_state_dict'])

        self.encoder_opt.load_state_dict(checkpoint['encoder_opt_state_dict'])
        self.dynamics_opt.load_state_dict(checkpoint['dynamics_opt_state_dict'])
        self.policy_opt.load_state_dict(checkpoint['policy_opt_state_dict'])

        self.total_steps = checkpoint['total_steps']
        self.episode = checkpoint['episode']
        self.train_stats = checkpoint['train_stats']
        self.causal_structure_history = checkpoint['causal_structure_history']

        print(f"从 {path} 加载检查点")
        print(f"从步骤 {self.total_steps}, 回合 {self.episode} 继续")